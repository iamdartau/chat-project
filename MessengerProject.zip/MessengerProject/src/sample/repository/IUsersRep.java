package sample.repository;

import sample.model.User;

import java.sql.SQLException;
import java.util.ArrayList;

public interface IUsersRep {

     User getUserbyloginandPassword (String login, String password) throws SQLException;
     void sign_up (User user) throws SQLException;
     ArrayList<User> getAll() throws SQLException;
}
