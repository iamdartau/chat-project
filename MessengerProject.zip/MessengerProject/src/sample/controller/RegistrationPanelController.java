package sample.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.Window;
import sample.Controller;
import sample.model.User;
import sample.repository.UsersRep;

import javax.jws.soap.SOAPBinding;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

public class RegistrationPanelController {

    UsersRep usersRep = new UsersRep();
    @FXML
    TextField name;
    @FXML
    TextField surname;
    @FXML
    TextField login;
    @FXML
    TextField password;

    String Name, Surname, Login, Password;
    ArrayList<User> users;

    @FXML
    public void initialize() throws SQLException {
        users = usersRep.getAll();
    }
    public void clickOnNext(ActionEvent actionEvent) throws SQLException {
        Name = name.getText();
        Surname = surname.getText();
        Login = login.getText();
        Password = password.getText();

        if (!isLogNotExists(Login))
        {
            usersRep.sign_up(new User(Name,Surname,Login,Password,"Y"));
            Controller.registerStage.close();
        }
        else
        {
            showAlertWithDefaultHeaderText();
            login.setText("");
        }
    }

    private void showAlertWithDefaultHeaderText() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");

        // alert.setHeaderText("Results:");
        alert.setContentText("User have login yet");

        alert.showAndWait();
    }

    public boolean isLogNotExists(String log)
    {
        for (User u: users
             ) {
            if(u.getLogin().equals(log))
                return true;

        }
        return false;
    }

    public void clickOnBack(ActionEvent actionEvent) {
    }
}
